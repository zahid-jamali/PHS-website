import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, varchar, pgEnum, json, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Product model
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  salePrice: doublePrecision("sale_price"),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  featured: boolean("featured").default(false),
  inStock: boolean("in_stock").default(true),
  weight: doublePrecision("weight"),
  dimensions: text("dimensions"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

// Order model
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zip: text("zip").notNull(),
  country: text("country").notNull(),
  total: doublePrecision("total").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

// Order Items model
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  price: doublePrecision("price").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
  createdAt: true,
});

// Contact form submissions
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

// Wholesale inquiries
export const wholesaleInquiries = pgTable("wholesale_inquiries", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  contactName: text("contact_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  businessType: text("business_type").notNull(),
  interests: text("interests").array().notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWholesaleInquirySchema = createInsertSchema(wholesaleInquiries).omit({
  id: true,
  createdAt: true,
});

// Newsletter subscriptions
export const newsletterSubscriptions = pgTable("newsletter_subscriptions", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertNewsletterSubscriptionSchema = createInsertSchema(newsletterSubscriptions).omit({
  id: true,
  createdAt: true,
});

// User role enum
export const userRoleEnum = pgEnum('user_role', ['user', 'admin']);

// User account table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  phone: text("phone"),
  profileImageUrl: text("profile_image_url"),
  role: userRoleEnum("role").default("user").notNull(),
  isVerified: boolean("is_verified").default(false),
  verificationToken: text("verification_token"),
  resetPasswordToken: text("reset_password_token"),
  resetPasswordExpires: timestamp("reset_password_expires"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  isVerified: true,
  verificationToken: true,
  resetPasswordToken: true,
  resetPasswordExpires: true,
});

// Session table for authentication
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

// Shipping addresses
export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  addressLine1: text("address_line1").notNull(),
  addressLine2: text("address_line2"),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zip: text("zip").notNull(),
  country: text("country").notNull(),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAddressSchema = createInsertSchema(addresses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Order tracking status enum
export const orderStatusEnum = pgEnum('order_status', [
  'pending',
  'processing', 
  'shipped', 
  'delivered', 
  'cancelled'
]);

// Order tracking
export const orderTracking = pgTable("order_tracking", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  status: orderStatusEnum("status").notNull(),
  trackingNumber: text("tracking_number"),
  carrier: text("carrier"),
  estimatedDelivery: timestamp("estimated_delivery"),
  actualDelivery: timestamp("actual_delivery"),
  locationUpdate: text("location_update"),
  notes: text("notes"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertOrderTrackingSchema = createInsertSchema(orderTracking).omit({
  id: true,
  updatedAt: true,
});

// Update orders table with user ID
export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(users, {
    fields: [orders.customerEmail],
    references: [users.email],
  }),
  items: many(orderItems),
  tracking: many(orderTracking),
}));

export const userRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  addresses: many(addresses),
  sessions: many(sessions),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id]
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id]
  })
}));

export const orderTrackingRelations = relations(orderTracking, ({ one }) => ({
  order: one(orders, {
    fields: [orderTracking.orderId],
    references: [orders.id]
  })
}));

export const addressRelations = relations(addresses, ({ one }) => ({
  user: one(users, {
    fields: [addresses.userId],
    references: [users.id]
  })
}));

// Subscription frequency enum
export const subscriptionFrequencyEnum = pgEnum('subscription_frequency', [
  'weekly',
  'biweekly',
  'monthly',
  'bimonthly',
  'quarterly'
]);

// Subscription model
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  frequency: subscriptionFrequencyEnum("frequency").notNull(),
  nextDeliveryDate: timestamp("next_delivery_date").notNull(),
  status: text("status").notNull().default("active"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  addressId: integer("address_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Subscription History model - to track all deliveries made
export const subscriptionHistory = pgTable("subscription_history", {
  id: serial("id").primaryKey(),
  subscriptionId: integer("subscription_id").notNull(),
  orderId: integer("order_id").notNull(),
  deliveryDate: timestamp("delivery_date").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSubscriptionHistorySchema = createInsertSchema(subscriptionHistory).omit({
  id: true,
  createdAt: true,
});

// Add relations for subscriptions
export const subscriptionRelations = relations(subscriptions, ({ one, many }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id]
  }),
  product: one(products, {
    fields: [subscriptions.productId],
    references: [products.id]
  }),
  address: one(addresses, {
    fields: [subscriptions.addressId],
    references: [addresses.id]
  }),
  history: many(subscriptionHistory)
}));

export const subscriptionHistoryRelations = relations(subscriptionHistory, ({ one }) => ({
  subscription: one(subscriptions, {
    fields: [subscriptionHistory.subscriptionId],
    references: [subscriptions.id]
  }),
  order: one(orders, {
    fields: [subscriptionHistory.orderId],
    references: [orders.id]
  })
}));

// Export types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type WholesaleInquiry = typeof wholesaleInquiries.$inferSelect;
export type InsertWholesaleInquiry = z.infer<typeof insertWholesaleInquirySchema>;

export type NewsletterSubscription = typeof newsletterSubscriptions.$inferSelect;
export type InsertNewsletterSubscription = z.infer<typeof insertNewsletterSubscriptionSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type Address = typeof addresses.$inferSelect;
export type InsertAddress = z.infer<typeof insertAddressSchema>;

export type OrderTracking = typeof orderTracking.$inferSelect;
export type InsertOrderTracking = z.infer<typeof insertOrderTrackingSchema>;

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;

export type SubscriptionHistory = typeof subscriptionHistory.$inferSelect;
export type InsertSubscriptionHistory = z.infer<typeof insertSubscriptionHistorySchema>;

// Product Reviews
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  userId: integer("user_id"),
  rating: integer("rating").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isVerified: boolean("is_verified").default(false),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

// Reviews relations
export const reviewsRelations = relations(reviews, ({ one }) => ({
  product: one(products, {
    fields: [reviews.productId],
    references: [products.id]
  }),
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id]
  })
}));

// Add reviews to products relations
export const productsRelations = relations(products, ({ many }) => ({
  orderItems: many(orderItems),
  reviews: many(reviews)
}));

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

// Green Rewards Program
export const carbonSavings = pgTable("carbon_savings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  orderId: integer("order_id"),
  description: text("description").notNull(),
  carbonSaved: doublePrecision("carbon_saved").notNull(), // in kg CO2e
  packagingMaterial: text("packaging_material"), 
  reuseTimes: integer("reuse_times"),
  transportationType: text("transportation_type"),
  pointsEarned: integer("points_earned").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCarbonSavingsSchema = createInsertSchema(carbonSavings).omit({
  id: true,
  createdAt: true,
});

export const greenRewards = pgTable("green_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  totalPoints: integer("total_points").notNull().default(0),
  lifetimeCarbonSaved: doublePrecision("lifetime_carbon_saved").notNull().default(0), // in kg CO2e
  treesPlanted: integer("trees_planted").notNull().default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertGreenRewardsSchema = createInsertSchema(greenRewards).omit({
  id: true,
  lastUpdated: true,
});

export const rewardRedemptions = pgTable("reward_redemptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rewardType: text("reward_type").notNull(), // discount, tree_planting, etc.
  pointsSpent: integer("points_spent").notNull(),
  discountCode: text("discount_code"),
  discountAmount: doublePrecision("discount_amount"),
  treeCount: integer("tree_count"),
  status: text("status").notNull().default("pending"), // pending, applied, completed
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRewardRedemptionSchema = createInsertSchema(rewardRedemptions).omit({
  id: true,
  createdAt: true,
});

// Add relations
export const carbonSavingsRelations = relations(carbonSavings, ({ one }) => ({
  user: one(users, {
    fields: [carbonSavings.userId],
    references: [users.id]
  }),
  order: one(orders, {
    fields: [carbonSavings.orderId],
    references: [orders.id]
  }),
}));

export const greenRewardsRelations = relations(greenRewards, ({ one }) => ({
  user: one(users, {
    fields: [greenRewards.userId],
    references: [users.id]
  }),
}));

export const rewardRedemptionsRelations = relations(rewardRedemptions, ({ one }) => ({
  user: one(users, {
    fields: [rewardRedemptions.userId],
    references: [users.id]
  }),
}));

// Update user relations to include green rewards
export const updatedUserRelations = relations(users, ({ many }) => ({
  orders: many(orders),
  addresses: many(addresses),
  sessions: many(sessions),
  carbonSavings: many(carbonSavings),
  greenRewards: many(greenRewards),
  redemptions: many(rewardRedemptions),
}));

export type CarbonSaving = typeof carbonSavings.$inferSelect;
export type InsertCarbonSaving = z.infer<typeof insertCarbonSavingsSchema>;

export type GreenReward = typeof greenRewards.$inferSelect;
export type InsertGreenReward = z.infer<typeof insertGreenRewardsSchema>;

export type RewardRedemption = typeof rewardRedemptions.$inferSelect;
export type InsertRewardRedemption = z.infer<typeof insertRewardRedemptionSchema>;

// Salt Flavor Mood Matcher
export const moodEnum = pgEnum('mood', [
  'energetic', 'relaxed', 'focused', 'creative', 'balanced', 'adventurous'
]);

export const tasteEnum = pgEnum('taste_profile', [
  'mild', 'medium', 'strong', 'exotic', 'herbal', 'spicy', 'smoky', 'citrusy', 'floral'
]);

export const saltFlavors = pgTable("salt_flavors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  tasteProfile: tasteEnum("taste_profile").notNull(),
  matchingMoods: moodEnum("matching_moods").array().notNull(),
  culinaryUses: text("culinary_uses").array(),
  benefitsDescription: text("benefits_description"),
  imageUrl: text("image_url").notNull(),
  productId: integer("product_id").references(() => products.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSaltFlavorSchema = createInsertSchema(saltFlavors).omit({
  id: true,
  createdAt: true,
});

export const saltFlavorRelations = relations(saltFlavors, ({ one }) => ({
  product: one(products, {
    fields: [saltFlavors.productId],
    references: [products.id]
  }),
}));

export const productsToSaltFlavorRelations = relations(products, ({ one }) => ({
  saltFlavor: one(saltFlavors, {
    fields: [products.id],
    references: [saltFlavors.productId]
  }),
}));

export type SaltFlavor = typeof saltFlavors.$inferSelect;
export type InsertSaltFlavor = z.infer<typeof insertSaltFlavorSchema>;
