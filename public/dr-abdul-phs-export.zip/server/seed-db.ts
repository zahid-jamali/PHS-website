import { db } from './db';
import { products, InsertProduct } from '@shared/schema';
import { Pool } from '@neondatabase/serverless';

// Define our sample products
const sampleProducts: InsertProduct[] = [
  // Culinary Products
  {
    name: "Premium Salt Grinder",
    slug: "premium-salt-grinder",
    description: "Our premium salt grinder filled with authentic Pink Himalayan Salt crystals, perfect for everyday cooking. The adjustable ceramic grinding mechanism allows for custom coarseness settings. Each grinder contains 100% pure Himalayan salt, ethically sourced from the Khewra Salt Mine in Pakistan.",
    price: 24.99,
    imageUrl: "/images/knowledge-centre/culinary-secrets-cooking-pink-salt.png",
    category: "culinary",
    featured: true,
    inStock: true,
    weight: 8.5,
    dimensions: "3x3x8 inches"
  },
  {
    name: "Cooking Block Set",
    slug: "cooking-block-set",
    description: "Set of 2 Himalayan Salt cooking blocks for grilling, serving, and cooking with a naturally enhanced flavor. Perfect for searing seafood, meat, or serving cold appetizers. Our cooking blocks have been carefully cut from the highest quality salt deposits, ensuring excellent heat retention and mineral-rich flavoring.",
    price: 59.99,
    imageUrl: "/images/knowledge-centre/ancient-origins-pink-himalayan-salt.jpg",
    category: "culinary",
    featured: true,
    inStock: true,
    weight: 16,
    dimensions: "8x8x2 inches"
  },
  {
    name: "Fine Ground Culinary Salt",
    slug: "fine-ground-culinary-salt",
    description: "Fine ground pink Himalayan salt, perfect for everyday cooking and baking. Contains over 84 trace minerals and elements for enhanced flavor and nutritional benefits. Our culinary salt is milled to the ideal consistency for cooking and baking, with no additives or anti-caking agents.",
    price: 12.99,
    imageUrl: "/images/knowledge-centre/pink-salt-vs-table-salt.webp",
    category: "culinary",
    featured: false,
    inStock: true,
    weight: 16,
    dimensions: "3x3x6 inches"
  },

  // Home & Decor Products
  {
    name: "Firebowl Salt Lamp",
    slug: "firebowl-salt-lamp",
    description: "Unique fire bowl design salt lamp hand-carved from authentic Himalayan salt crystals, creates a warm, relaxing ambiance that resembles a glowing flame. Each piece is uniquely crafted by skilled artisans at the Khewra Salt Mine, with a natural orange-amber glow that soothes and calms.",
    price: 34.99,
    salePrice: 29.99,
    imageUrl: "/images/knowledge-centre/powerful-synergetic-action-phs.jpg",
    category: "home",
    featured: true,
    inStock: true,
    weight: 6,
    dimensions: "5x5x8 inches"
  },
  {
    name: "PHS Chunk Lamp",
    slug: "phs-chunk-lamp",
    description: "Beautiful pink Himalayan chunks in an elegant iron pot, perfect for your living room or kitchen. Purifies surrounding air by removing pathogens and toxins with powerful detoxifying properties. The salt chunks are carefully selected for their color variation and therapeutic qualities.",
    price: 39.99,
    imageUrl: "/images/knowledge-centre/healing-power-pink-himalayan-salt.webp",
    category: "home",
    featured: true,
    inStock: true,
    weight: 3.2,
    dimensions: "4x4x5 inches"
  },
  {
    name: "Carved Salt Lamp",
    slug: "carved-salt-lamp",
    description: "Artistically carved Himalayan salt lamps in various designs including spheres, pyramids, and bowls. Each piece is a beautiful functional art object that serves as both home decor and a natural air purifier. The smooth, polished surface showcases the natural variations in the salt's color and texture.",
    price: 49.99,
    imageUrl: "/images/knowledge-centre/halotherapy-comprehensive-guide.webp",
    category: "home",
    featured: true,
    inStock: true,
    weight: 6.0,
    dimensions: "6x6x7 inches"
  },
  {
    name: "USB Salt Lamp",
    slug: "usb-salt-lamp",
    description: "Compact USB-powered Himalayan salt lamps perfect for desks, offices, or travel. Enjoy the benefits of salt therapy wherever you go. These small but powerful salt lamps are ideal for purifying the air in your workspace or creating a calming atmosphere in any small area.",
    price: 24.99,
    imageUrl: "/images/knowledge-centre/setting-up-salt-therapy-room.webp",
    category: "home",
    featured: true,
    inStock: true,
    weight: 1.5,
    dimensions: "3x3x4 inches"
  },

  // Therapeutic Products
  {
    name: "Bath Salt Blend",
    slug: "bath-salt-blend",
    description: "Therapeutic bath salt blend with essential oils for relaxation and detoxification. Our special formulation helps soothe sore muscles and improve skin health. The mineral-rich composition helps draw out toxins, reduce inflammation, and promote overall wellbeing through transdermal absorption.",
    price: 19.99,
    imageUrl: "/images/knowledge-centre/powerful-synergetic-action-phs.jpg",
    category: "therapeutic",
    featured: true,
    inStock: true,
    weight: 16,
    dimensions: "4x4x6 inches"
  },
  {
    name: "Salt Inhaler",
    slug: "salt-inhaler",
    description: "Ceramic salt inhaler filled with pure Himalayan salt crystals for respiratory support. A natural way to potentially ease symptoms of allergies, asthma, and sinus conditions. The inhaler delivers microscopic salt particles to the respiratory system as you breathe, helping to cleanse and open airways.",
    price: 29.99,
    imageUrl: "/images/knowledge-centre/halotherapy-comprehensive-guide.webp",
    category: "therapeutic",
    featured: false,
    inStock: true,
    weight: 0.5,
    dimensions: "2x2x4 inches"
  },

  // Halotherapy Products
  {
    name: "Himalayan Salt Tiles Set",
    slug: "himalayan-salt-tiles-set",
    description: "Set of 6 salt tiles perfect for building salt walls in saunas or halotherapy rooms. Creates a stunning visual feature while providing therapeutic benefits through natural salt diffusion. Our tiles are precision-cut to ensure easy installation and maximum surface area for salt therapy.",
    price: 149.99,
    imageUrl: "/images/knowledge-centre/animal-licks-minerals-livestock-wildlife.webp",
    category: "halotherapy",
    featured: false,
    inStock: true,
    weight: 30,
    dimensions: "8x4x2 inches each"
  },
  {
    name: "Halotherapy Salt",
    slug: "halotherapy-salt",
    description: "Pharmaceutical-grade salt specifically processed for halogenerators and salt therapy rooms. Micronized for optimal dispersion in salt therapy environments. Tested for purity and particle size to ensure the most effective therapeutic experience in professional salt therapy applications.",
    price: 39.99,
    imageUrl: "/images/knowledge-centre/pink-salt-vs-table-salt.webp",
    category: "halotherapy",
    featured: false,
    inStock: true,
    weight: 22,
    dimensions: "10x8x4 inches"
  },
  {
    name: "Salt Wall DIY Installation Kit",
    slug: "salt-wall-diy-installation-kit",
    description: "Complete kit for building a 4x6 foot Himalayan salt wall, including salt bricks, mounting hardware, and LED lighting. Perfect for home salt rooms, spas, or yoga studios. Includes detailed step-by-step instructions and all necessary materials for creating your own professional-grade salt therapy wall.",
    price: 599.99,
    imageUrl: "/images/knowledge-centre/setting-up-salt-therapy-room.webp",
    category: "halotherapy",
    featured: true,
    inStock: true,
    weight: 150,
    dimensions: "48x12x24 inches"
  }
];

async function seedDatabase() {
  console.log('Starting database seeding...');

  try {
    // Clear existing products
    await db.delete(products);
    console.log('Cleared existing products.');

    // Insert new products
    for (const product of sampleProducts) {
      await db.insert(products).values(product);
      console.log(`Added product: ${product.name}`);
    }

    console.log('Database seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
  
  console.log('Exiting process...');
}

// Run the seeding function
seedDatabase();