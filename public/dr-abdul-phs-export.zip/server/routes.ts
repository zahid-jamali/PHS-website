import type { Express, Request as ExpressRequest, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer } from 'ws';
import { v4 as uuid } from 'uuid';
import { 
  insertContactSchema, 
  insertNewsletterSubscriptionSchema, 
  insertOrderSchema, 
  insertOrderItemSchema, 
  insertWholesaleInquirySchema, 
  insertReviewSchema, 
  insertUserSchema,
  insertCarbonSavingsSchema,
  insertRewardRedemptionSchema,
  insertSaltFlavorSchema
} from "@shared/schema";
import { ChatService } from "./chat-service";
import { z } from "zod";
import bcrypt from "bcrypt";

// Extended Request type with authentication properties
interface Request extends ExpressRequest {
  isAuthenticated?: () => boolean;
  user?: {
    id: number;
    email: string;
    [key: string]: any;
  };
}

// Helper middleware functions
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated && req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "User not authenticated" });
};

const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated && req.isAuthenticated()) {
    if (req.user && req.user.role === 'admin') {
      return next();
    }
    return res.status(403).json({ message: "Unauthorized. Admin access required." });
  }
  res.status(401).json({ message: "User not authenticated" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server for both Express and WebSocket
  const httpServer = createServer(app);
  
  // Initialize chat service
  const chatService = new ChatService(httpServer);
  
  // API routes
  app.get("/api/products", async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/featured", async (req: Request, res: Response) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured products" });
    }
  });

  app.get("/api/products/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products by category" });
    }
  });

  app.get("/api/products/:slug", async (req: Request, res: Response) => {
    try {
      const { slug } = req.params;
      const product = await storage.getProductBySlug(slug);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Order creation
  app.post("/api/orders", async (req: Request, res: Response) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      
      // If there are order items in the request body, create them as well
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const orderItemData = insertOrderItemSchema.parse({
            ...item,
            orderId: order.id
          });
          await storage.createOrderItem(orderItemData);
        }
      }
      
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Contact form submissions
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit contact form" });
    }
  });

  // Wholesale inquiries
  app.post("/api/wholesale", async (req: Request, res: Response) => {
    try {
      const inquiryData = insertWholesaleInquirySchema.parse(req.body);
      const inquiry = await storage.createWholesaleInquiry(inquiryData);
      res.status(201).json(inquiry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid wholesale inquiry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit wholesale inquiry" });
    }
  });

  // Newsletter subscriptions
  app.post("/api/newsletter", async (req: Request, res: Response) => {
    try {
      const subscriptionData = insertNewsletterSubscriptionSchema.parse(req.body);
      const subscription = await storage.createNewsletterSubscription(subscriptionData);
      res.status(201).json(subscription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid email address", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });
  
  // Public order tracking endpoint (requires order number and email)
  app.get("/api/track-order", async (req: Request, res: Response) => {
    try {
      const { orderNumber, email } = req.query;
      
      if (!orderNumber || !email) {
        return res.status(400).json({ 
          message: "Order number and email are required" 
        });
      }
      
      const orderId = parseInt(orderNumber.toString().replace('ORD-', ''));
      
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order number format" });
      }
      
      // Get order details
      const order = await storage.getOrder(orderId);
      
      if (!order || order.customerEmail !== email) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Get order items
      const items = await storage.getOrderItems(orderId);
      
      // Get order tracking
      const trackingHistory = await storage.getOrderTrackingByOrderId(orderId);
      
      // Get latest tracking entry
      const latestTracking = trackingHistory.length > 0 
        ? trackingHistory[0] 
        : null;
      
      // Return tracking information
      res.json({
        order,
        items,
        tracking: latestTracking,
        trackingHistory
      });
    } catch (error) {
      console.error("Error tracking order:", error);
      res.status(500).json({ message: "Failed to retrieve tracking information" });
    }
  });
  
  // Get user orders (for authenticated users)
  app.get("/api/account/orders", async (req: Request, res: Response) => {
    try {
      // Get user ID from the session (this would be implemented with your authentication system)
      // For demo purposes, we'll return all orders
      const orders = await storage.getOrders();
      
      // For each order, fetch item count
      const ordersWithItemCount = await Promise.all(
        orders.map(async (order) => {
          const items = await storage.getOrderItems(order.id);
          return {
            ...order,
            itemCount: items.length
          };
        })
      );
      
      res.json(ordersWithItemCount);
    } catch (error) {
      console.error("Error fetching user orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Order tracking endpoint for authenticated users
  app.get("/api/orders/:orderId/tracking", async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.orderId);
      
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      // Get order details
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Get order items
      const items = await storage.getOrderItems(orderId);
      
      // Fetch product details for each item
      const itemsWithProducts = await Promise.all(
        items.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      // Get order tracking history
      const trackingHistory = await storage.getOrderTrackingByOrderId(orderId);
      
      // Sort tracking by date (newest first)
      trackingHistory.sort((a, b) => {
        const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
        const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
        return dateB - dateA;
      });
      
      // Get latest tracking entry
      const latestTracking = trackingHistory.length > 0 
        ? trackingHistory[0] 
        : null;
      
      // Return tracking information
      res.json({
        order,
        items: itemsWithProducts,
        tracking: latestTracking,
        trackingHistory
      });
    } catch (error) {
      console.error("Error retrieving order tracking:", error);
      res.status(500).json({ message: "Failed to retrieve tracking information" });
    }
  });
  
  // Subscription endpoints
  
  // Create new subscription
  app.post("/api/subscriptions", async (req: Request, res: Response) => {
    try {
      const { productId, quantity, frequency, addressId } = req.body;
      
      if (!productId || !quantity || !frequency || !addressId) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      
      // Calculate next delivery date based on frequency
      const nextDeliveryDate = new Date();
      switch (frequency) {
        case 'weekly':
          nextDeliveryDate.setDate(nextDeliveryDate.getDate() + 7);
          break;
        case 'biweekly':
          nextDeliveryDate.setDate(nextDeliveryDate.getDate() + 14);
          break;
        case 'monthly':
          nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 1);
          break;
        case 'bimonthly':
          nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 2);
          break;
        case 'quarterly':
          nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 3);
          break;
        default:
          nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 1); // Default to monthly
      }
      
      const subscription = await storage.createSubscription({
        userId,
        productId: Number(productId),
        quantity: Number(quantity),
        frequency,
        nextDeliveryDate,
        status: 'active',
        addressId: Number(addressId)
      });
      
      res.status(201).json(subscription);
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });
  
  // Get user subscriptions
  app.get("/api/account/subscriptions", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      const subscriptions = await storage.getSubscriptionsByUserId(userId);
      
      res.json(subscriptions);
    } catch (error) {
      console.error("Error fetching subscriptions:", error);
      res.status(500).json({ message: "Failed to fetch subscriptions" });
    }
  });
  
  // Get subscription history
  app.get("/api/account/subscription-history", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      const subscriptions = await storage.getSubscriptionsByUserId(userId);
      
      // Get history for all user subscriptions
      const history = [];
      for (const subscription of subscriptions) {
        const subscriptionHistory = await storage.getSubscriptionHistoryBySubscriptionId(subscription.id);
        history.push(...subscriptionHistory);
      }
      
      // Sort by delivery date (newest first)
      history.sort((a, b) => {
        const dateA = a.deliveryDate ? new Date(a.deliveryDate).getTime() : 0;
        const dateB = b.deliveryDate ? new Date(b.deliveryDate).getTime() : 0;
        return dateB - dateA;
      });
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching subscription history:", error);
      res.status(500).json({ message: "Failed to fetch subscription history" });
    }
  });
  
  // Get user addresses
  app.get("/api/account/addresses", async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      const addresses = await storage.getAddressesByUserId(userId);
      res.json(addresses);
    } catch (error) {
      console.error("Error fetching user addresses:", error);
      res.status(500).json({ message: "Failed to fetch user addresses" });
    }
  });
  
  // Update subscription
  app.patch("/api/subscriptions/:id", async (req: Request, res: Response) => {
    try {
      const subscriptionId = parseInt(req.params.id);
      const { quantity, frequency, status } = req.body;
      
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      
      // Get the subscription and confirm ownership
      const subscription = await storage.getSubscriptionById(subscriptionId);
      if (!subscription) {
        return res.status(404).json({ message: "Subscription not found" });
      }
      
      if (subscription.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this subscription" });
      }
      
      // Update subscription
      const updateData: any = {};
      
      if (quantity !== undefined) {
        updateData.quantity = quantity;
      }
      
      if (frequency !== undefined) {
        updateData.frequency = frequency;
        
        // Calculate next delivery date based on new frequency
        const nextDeliveryDate = new Date();
        switch (frequency) {
          case 'weekly':
            nextDeliveryDate.setDate(nextDeliveryDate.getDate() + 7);
            break;
          case 'biweekly':
            nextDeliveryDate.setDate(nextDeliveryDate.getDate() + 14);
            break;
          case 'monthly':
            nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 1);
            break;
          case 'bimonthly':
            nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 2);
            break;
          case 'quarterly':
            nextDeliveryDate.setMonth(nextDeliveryDate.getMonth() + 3);
            break;
        }
        
        updateData.nextDeliveryDate = nextDeliveryDate;
      }
      
      if (status !== undefined) {
        updateData.status = status;
      }
      
      const updatedSubscription = await storage.updateSubscription(subscriptionId, updateData);
      
      res.json(updatedSubscription);
    } catch (error) {
      console.error("Error updating subscription:", error);
      res.status(500).json({ message: "Failed to update subscription" });
    }
  });
  
  // Cancel subscription
  app.post("/api/subscriptions/:id/cancel", async (req: Request, res: Response) => {
    try {
      const subscriptionId = parseInt(req.params.id);
      
      // Check if user is authenticated
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userId = req.user.id;
      
      // Get the subscription and confirm ownership
      const subscription = await storage.getSubscriptionById(subscriptionId);
      if (!subscription) {
        return res.status(404).json({ message: "Subscription not found" });
      }
      
      if (subscription.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to cancel this subscription" });
      }
      
      // Cancel subscription
      const canceledSubscription = await storage.cancelSubscription(subscriptionId);
      
      res.json(canceledSubscription);
    } catch (error) {
      console.error("Error canceling subscription:", error);
      res.status(500).json({ message: "Failed to cancel subscription" });
    }
  });

  // Review routes
  app.get("/api/reviews", async (req: Request, res: Response) => {
    try {
      const reviews = await storage.getReviews();
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/products/:productId/reviews", async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const reviews = await storage.getReviewsByProductId(productId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching product reviews:", error);
      res.status(500).json({ message: "Failed to fetch product reviews" });
    }
  });

  app.post("/api/reviews", async (req: Request, res: Response) => {
    try {
      const reviewData = insertReviewSchema.parse(req.body);
      
      // If user is authenticated, associate review with user
      if (req.isAuthenticated && req.isAuthenticated()) {
        reviewData.userId = req.user?.id;
      }
      
      const newReview = await storage.createReview(reviewData);
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.patch("/api/reviews/:id/status", async (req: Request, res: Response) => {
    try {
      // Admin-only route
      if (!req.isAuthenticated || !req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid review ID" });
      }
      
      const { status } = req.body;
      if (!status || typeof status !== "string") {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedReview = await storage.updateReviewStatus(id, status);
      
      if (!updatedReview) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      res.json(updatedReview);
    } catch (error) {
      console.error("Error updating review status:", error);
      res.status(500).json({ message: "Failed to update review status" });
    }
  });

  app.delete("/api/reviews/:id", async (req: Request, res: Response) => {
    try {
      // Admin-only route or user can delete their own review
      if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid review ID" });
      }
      
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Check if user is admin or the author of the review
      if (req.user?.role !== "admin" && review.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized to delete this review" });
      }
      
      await storage.deleteReview(id);
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting review:", error);
      res.status(500).json({ message: "Failed to delete review" });
    }
  });

  // Admin User Management Routes
  
  // Get all users (admin only)
  app.get("/api/admin/users", isAdmin, async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      // Don't send password hashes to client
      const sanitizedUsers = users.map(user => {
        const { passwordHash, ...userData } = user;
        return userData;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Create a new user (admin only)
  app.post("/api/admin/users", isAdmin, async (req: Request, res: Response) => {
    try {
      // Validate input data
      const userDataSchema = z.object({
        firstName: z.string().min(2),
        lastName: z.string().min(2),
        email: z.string().email(),
        password: z.string().min(8),
        role: z.enum(["user", "admin"]),
        phone: z.string().optional(),
      });
      
      const validatedData = userDataSchema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(409).json({ message: "Email already registered" });
      }
      
      // Hash password
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(validatedData.password, saltRounds);
      
      // Create user with hashed password
      const { password, ...userData } = validatedData;
      const newUser = await storage.createUser({
        ...userData,
        passwordHash,
        isVerified: true, // Admin-created users are automatically verified
      });
      
      // Remove password hash from response
      const { passwordHash: _, ...safeUserData } = newUser;
      
      res.status(201).json(safeUserData);
    } catch (error) {
      console.error("Error creating user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  // Update a user (admin only)
  app.patch("/api/admin/users/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get existing user to check if it exists
      const existingUser = await storage.getUserById(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate update data
      const updateSchema = z.object({
        firstName: z.string().min(2).optional(),
        lastName: z.string().min(2).optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        role: z.enum(["user", "admin"]).optional(),
        password: z.string().min(8).optional(),
      });
      
      const validatedData = updateSchema.parse(req.body);
      
      // If email is being updated, check if it's already in use by another user
      if (validatedData.email && validatedData.email !== existingUser.email) {
        const userWithEmail = await storage.getUserByEmail(validatedData.email);
        if (userWithEmail && userWithEmail.id !== userId) {
          return res.status(409).json({ message: "Email already in use by another user" });
        }
      }
      
      // Prepare update data
      let updateData: any = { ...validatedData };
      delete updateData.password;
      
      // If password is provided, hash it
      if (validatedData.password) {
        const saltRounds = 10;
        updateData.passwordHash = await bcrypt.hash(validatedData.password, saltRounds);
      }
      
      // Update user
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password hash from response
      const { passwordHash, ...safeUserData } = updatedUser;
      
      res.json(safeUserData);
    } catch (error) {
      console.error("Error updating user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Delete a user (admin only)
  app.delete("/api/admin/users/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Check if user exists
      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Prevent deleting the currently logged-in user
      if (req.user && req.user.id === userId) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      // Delete user
      await storage.deleteUser(userId);
      
      res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  
  // Admin Product Management Routes
  app.get("/api/admin/products", isAdmin, async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching admin products:", error);
      res.status(500).json({ message: "Failed to fetch products for admin" });
    }
  });
  
  // Green Rewards - Carbon Savings API Routes
  app.get("/api/carbon-savings", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const carbonSavings = await storage.getCarbonSavingsByUserId(req.user.id);
      res.json(carbonSavings);
    } catch (error) {
      console.error("Error fetching carbon savings:", error);
      res.status(500).json({ message: "Failed to fetch carbon savings" });
    }
  });
  
  app.post("/api/carbon-savings", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const carbonSavingData = insertCarbonSavingsSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const carbonSaving = await storage.createCarbonSaving(carbonSavingData);
      res.status(201).json(carbonSaving);
    } catch (error) {
      console.error("Error creating carbon saving:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create carbon saving record" });
    }
  });
  
  // Green Rewards - User Rewards API Routes
  app.get("/api/green-rewards", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const greenReward = await storage.getGreenRewardByUserId(req.user.id);
      
      if (!greenReward) {
        return res.status(404).json({ message: "Green rewards profile not found" });
      }
      
      res.json(greenReward);
    } catch (error) {
      console.error("Error fetching green rewards:", error);
      res.status(500).json({ message: "Failed to fetch green rewards" });
    }
  });
  
  // Green Rewards - Redemptions API Routes
  app.get("/api/reward-redemptions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      const redemptions = await storage.getRewardRedemptionsByUserId(req.user.id);
      res.json(redemptions);
    } catch (error) {
      console.error("Error fetching reward redemptions:", error);
      res.status(500).json({ message: "Failed to fetch reward redemptions" });
    }
  });
  
  app.post("/api/reward-redemptions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      // Get user's current green rewards
      const greenReward = await storage.getGreenRewardByUserId(req.user.id);
      
      if (!greenReward) {
        return res.status(404).json({ message: "Green rewards profile not found" });
      }
      
      // Validate redemption data
      const redemptionData = insertRewardRedemptionSchema.parse({
        ...req.body,
        userId: req.user.id,
        status: "pending"
      });
      
      // Check if user has enough points
      if (greenReward.totalPoints < redemptionData.pointsSpent) {
        return res.status(400).json({ 
          message: "Insufficient points for redemption",
          availablePoints: greenReward.totalPoints,
          requestedPoints: redemptionData.pointsSpent 
        });
      }
      
      const redemption = await storage.createRewardRedemption(redemptionData);
      res.status(201).json(redemption);
    } catch (error) {
      console.error("Error creating reward redemption:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create reward redemption" });
    }
  });
  
  // Salt Flavor Mood Matcher Routes
  app.get("/api/salt-flavors", async (req: Request, res: Response) => {
    try {
      const saltFlavors = await storage.getSaltFlavors();
      res.json(saltFlavors);
    } catch (error) {
      console.error("Error fetching salt flavors:", error);
      res.status(500).json({ message: "Failed to fetch salt flavors" });
    }
  });
  
  app.get("/api/salt-flavors/mood/:mood", async (req: Request, res: Response) => {
    try {
      const mood = req.params.mood;
      const saltFlavors = await storage.getSaltFlavorsByMood(mood);
      res.json(saltFlavors);
    } catch (error) {
      console.error("Error fetching salt flavors by mood:", error);
      res.status(500).json({ message: "Failed to fetch salt flavors by mood" });
    }
  });
  
  app.get("/api/salt-flavors/taste/:tasteProfile", async (req: Request, res: Response) => {
    try {
      const tasteProfile = req.params.tasteProfile;
      const saltFlavors = await storage.getSaltFlavorsByTasteProfile(tasteProfile);
      res.json(saltFlavors);
    } catch (error) {
      console.error("Error fetching salt flavors by taste profile:", error);
      res.status(500).json({ message: "Failed to fetch salt flavors by taste profile" });
    }
  });
  
  app.get("/api/salt-flavors/:idOrSlug", async (req: Request, res: Response) => {
    try {
      const idOrSlug = req.params.idOrSlug;
      let saltFlavor;
      
      // Check if the param is a number (ID) or string (slug)
      const id = parseInt(idOrSlug);
      if (!isNaN(id)) {
        saltFlavor = await storage.getSaltFlavorById(id);
      } else {
        saltFlavor = await storage.getSaltFlavorBySlug(idOrSlug);
      }
      
      if (!saltFlavor) {
        return res.status(404).json({ message: "Salt flavor not found" });
      }
      
      res.json(saltFlavor);
    } catch (error) {
      console.error("Error fetching salt flavor:", error);
      res.status(500).json({ message: "Failed to fetch salt flavor" });
    }
  });
  
  // Admin Salt Flavor Management Routes
  app.post("/api/admin/salt-flavors", isAdmin, async (req: Request, res: Response) => {
    try {
      const saltFlavorData = insertSaltFlavorSchema.parse(req.body);
      const saltFlavor = await storage.createSaltFlavor(saltFlavorData);
      res.status(201).json(saltFlavor);
    } catch (error) {
      console.error("Error creating salt flavor:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create salt flavor" });
    }
  });
  
  app.patch("/api/admin/salt-flavors/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid salt flavor ID" });
      }
      
      // Check if salt flavor exists
      const saltFlavor = await storage.getSaltFlavorById(id);
      if (!saltFlavor) {
        return res.status(404).json({ message: "Salt flavor not found" });
      }
      
      const updatedSaltFlavor = await storage.updateSaltFlavor(id, req.body);
      res.json(updatedSaltFlavor);
    } catch (error) {
      console.error("Error updating salt flavor:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update salt flavor" });
    }
  });
  
  app.delete("/api/admin/salt-flavors/:id", isAdmin, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid salt flavor ID" });
      }
      
      // Check if salt flavor exists
      const saltFlavor = await storage.getSaltFlavorById(id);
      if (!saltFlavor) {
        return res.status(404).json({ message: "Salt flavor not found" });
      }
      
      await storage.deleteSaltFlavor(id);
      res.status(200).json({ message: "Salt flavor deleted successfully" });
    } catch (error) {
      console.error("Error deleting salt flavor:", error);
      res.status(500).json({ message: "Failed to delete salt flavor" });
    }
  });
  
  // Admin Green Rewards Management Routes
  app.get("/api/admin/carbon-savings", isAdmin, async (req: Request, res: Response) => {
    try {
      // Simple implementation to get all carbon savings
      // In a real app, you'd want pagination and filtering
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      let carbonSavings;
      if (userId) {
        carbonSavings = await storage.getCarbonSavingsByUserId(userId);
      } else {
        carbonSavings = await storage.getAllCarbonSavings();
      }
      
      res.json(carbonSavings);
    } catch (error) {
      console.error("Error fetching carbon savings for admin:", error);
      res.status(500).json({ message: "Failed to fetch carbon savings" });
    }
  });
  
  app.put("/api/admin/reward-redemptions/:id/status", isAdmin, async (req: Request, res: Response) => {
    try {
      const redemptionId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["pending", "approved", "rejected", "completed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const updatedRedemption = await storage.updateRewardRedemptionStatus(redemptionId, status);
      
      if (!updatedRedemption) {
        return res.status(404).json({ message: "Reward redemption not found" });
      }
      
      res.json(updatedRedemption);
    } catch (error) {
      console.error("Error updating redemption status:", error);
      res.status(500).json({ message: "Failed to update redemption status" });
    }
  });

  return httpServer;
}
