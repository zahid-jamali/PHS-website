import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { randomUUID } from 'crypto';

// Chat message types
export enum MessageType {
  USER_MESSAGE = 'user_message',
  ADMIN_MESSAGE = 'admin_message',
  BOT_MESSAGE = 'bot_message',
  SYSTEM_MESSAGE = 'system_message',
  JOIN = 'join',
  LEAVE = 'leave',
}

// Chat message interface
export interface ChatMessage {
  id: string;
  type: MessageType;
  sender: string;
  text: string;
  timestamp: number;
}

// Client connection interface
interface Client {
  id: string;
  username: string | null;
  socket: WebSocket;
  isAdmin: boolean;
}

// Auto-response patterns for chatbot
const autoResponses = [
  {
    patterns: ['hello', 'hi', 'hey', 'greetings'],
    responses: [
      "Hello! Welcome to Dr. Abdul PHS. How can I assist you today?",
      "Hi there! Thank you for contacting Dr. Abdul PHS. How may I help you?",
      "Hello! I'm the Dr. Abdul PHS virtual assistant. What can I help you with?"
    ]
  },
  {
    patterns: ['shipping', 'delivery', 'ship', 'track'],
    responses: [
      "We offer worldwide shipping on all our Pink Himalayan Salt products. Standard shipping times vary by region from 3-14 business days.",
      "You can track your order in the customer portal under 'Order History'. For any specific shipping queries, please provide your order number."
    ]
  },
  {
    patterns: ['wholesale', 'bulk', 'business'],
    responses: [
      "We offer special pricing for wholesale and bulk orders. Please visit our Wholesale page or share your business details and requirements, and our team will contact you shortly."
    ]
  },
  {
    patterns: ['products', 'catalog', 'range', 'offer'],
    responses: [
      "We offer a wide range of Pink Himalayan Salt products including culinary salts, bath & spa products, salt lamps, and halotherapy equipment. Would you like information about a specific category?"
    ]
  },
  {
    patterns: ['price', 'cost', 'pricing'],
    responses: [
      "Our product prices vary based on category, size, and specifications. You can view detailed pricing on each product page. For bulk or wholesale pricing, please ask about our wholesale program."
    ]
  },
  {
    patterns: ['help', 'support', 'assistance', 'question'],
    responses: [
      "I'm here to help! Please let me know what specific information you're looking for about our Pink Himalayan Salt products or services."
    ]
  },
  {
    patterns: ['contact', 'email', 'phone', 'reach'],
    responses: [
      "You can contact our customer service team via email at support@drabdul-phs.com or by phone at +1-555-SALT-PHS (555-725-8747). Our working hours are Monday to Friday, 9 AM to 5 PM EST."
    ]
  },
  {
    patterns: ['salt', 'origin', 'source', 'himalayan'],
    responses: [
      "Our Pink Himalayan Salt is sourced directly from the ancient Khewra Salt Mine in Pakistan, which formed over 250 million years ago when prehistoric oceans evaporated. It contains 84+ minerals and trace elements beneficial for health."
    ]
  },
  {
    patterns: ['lamp', 'light', 'glow'],
    responses: [
      "Our Himalayan Salt Lamps are hand-carved from pure salt crystals mined from the Khewra Salt Mine. They emit a warm, amber glow and are believed to release negative ions that can improve air quality and mood."
    ]
  },
  {
    patterns: ['health', 'benefits', 'mineral', 'wellness'],
    responses: [
      "Pink Himalayan Salt contains 84+ minerals and trace elements including potassium, magnesium, and calcium. It's known for potentially helping with respiratory issues, skin conditions, and promoting better sleep and mood when used in various forms."
    ]
  }
];

export class ChatService {
  private wss: WebSocketServer;
  private clients: Map<string, Client> = new Map();
  private messageHistory: ChatMessage[] = [];
  private maxHistoryLength = 100;

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws/chat' });
    this.initialize();
  }

  private initialize() {
    this.wss.on('connection', (socket: WebSocket) => {
      const clientId = randomUUID();
      
      // Add new client
      this.clients.set(clientId, {
        id: clientId,
        username: null,
        socket,
        isAdmin: false
      });

      // Send connection confirmation
      this.sendToClient(clientId, {
        id: randomUUID(),
        type: MessageType.SYSTEM_MESSAGE,
        sender: 'system',
        text: 'Connected to chat. Please type your question.',
        timestamp: Date.now()
      });

      // Send message history to new client
      this.messageHistory.forEach(message => {
        this.sendToClient(clientId, message);
      });

      // Handle incoming messages
      socket.on('message', (rawData: string) => {
        try {
          const data = JSON.parse(rawData);
          
          // Process initial identification message
          if (data.action === 'identify') {
            const client = this.clients.get(clientId);
            if (client) {
              client.username = data.username || `Guest-${clientId.slice(0, 4)}`;
              client.isAdmin = data.isAdmin || false;
              
              // Notify all clients about new user
              const joinMessage: ChatMessage = {
                id: randomUUID(),
                type: MessageType.JOIN,
                sender: 'system',
                text: `${client.username} has joined the chat`,
                timestamp: Date.now()
              };
              this.broadcastMessage(joinMessage);
            }
            return;
          }

          // Process chat messages
          if (data.action === 'message' && data.text) {
            const client = this.clients.get(clientId);
            if (!client || !client.username) return;

            const messageId = randomUUID();
            const message: ChatMessage = {
              id: messageId,
              type: client.isAdmin ? MessageType.ADMIN_MESSAGE : MessageType.USER_MESSAGE,
              sender: client.username,
              text: data.text,
              timestamp: Date.now()
            };

            // Save and broadcast message
            this.addMessageToHistory(message);
            this.broadcastMessage(message);

            // Generate bot response if not admin message
            if (!client.isAdmin) {
              setTimeout(() => {
                this.sendBotResponse(data.text);
              }, 1000);
            }
          }
        } catch (error) {
          console.error('Error processing message:', error);
        }
      });

      // Handle disconnection
      socket.on('close', () => {
        const client = this.clients.get(clientId);
        if (client && client.username) {
          const leaveMessage: ChatMessage = {
            id: randomUUID(),
            type: MessageType.LEAVE,
            sender: 'system',
            text: `${client.username} has left the chat`,
            timestamp: Date.now()
          };
          this.broadcastMessage(leaveMessage);
        }
        
        this.clients.delete(clientId);
      });
    });

    console.log('Chat service initialized');
  }

  private sendToClient(clientId: string, message: ChatMessage) {
    const client = this.clients.get(clientId);
    if (client && client.socket.readyState === WebSocket.OPEN) {
      client.socket.send(JSON.stringify(message));
    }
  }

  private broadcastMessage(message: ChatMessage) {
    this.addMessageToHistory(message);
    this.clients.forEach((client) => {
      if (client.socket.readyState === WebSocket.OPEN) {
        client.socket.send(JSON.stringify(message));
      }
    });
  }

  private addMessageToHistory(message: ChatMessage) {
    this.messageHistory.push(message);
    if (this.messageHistory.length > this.maxHistoryLength) {
      this.messageHistory.shift();
    }
  }

  private sendBotResponse(userMessage: string) {
    // Convert to lowercase for pattern matching
    const lowerCaseMessage = userMessage.toLowerCase();
    
    // Check for matching patterns
    for (const autoResponse of autoResponses) {
      if (autoResponse.patterns.some(pattern => lowerCaseMessage.includes(pattern))) {
        const responseIndex = Math.floor(Math.random() * autoResponse.responses.length);
        const botResponse: ChatMessage = {
          id: randomUUID(),
          type: MessageType.BOT_MESSAGE,
          sender: 'Dr. Abdul Assistant',
          text: autoResponse.responses[responseIndex],
          timestamp: Date.now()
        };
        
        this.broadcastMessage(botResponse);
        return;
      }
    }
    
    // Default response if no pattern matches
    const defaultResponse: ChatMessage = {
      id: randomUUID(),
      type: MessageType.BOT_MESSAGE,
      sender: 'Dr. Abdul Assistant',
      text: "Thank you for your message. If you have specific questions about our Pink Himalayan Salt products, please ask. For complex inquiries, a customer service representative will follow up with you soon.",
      timestamp: Date.now()
    };
    
    this.broadcastMessage(defaultResponse);
  }
}