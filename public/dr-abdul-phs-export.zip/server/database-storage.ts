import { 
  products, 
  orders, 
  orderItems, 
  contacts, 
  wholesaleInquiries, 
  newsletterSubscriptions,
  users,
  sessions,
  addresses,
  orderTracking,
  subscriptions,
  subscriptionHistory,
  reviews,
  carbonSavings,
  greenRewards,
  rewardRedemptions,
  saltFlavors,
  type Product, 
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type Contact,
  type InsertContact,
  type WholesaleInquiry,
  type InsertWholesaleInquiry,
  type NewsletterSubscription,
  type InsertNewsletterSubscription,
  type User,
  type InsertUser,
  type Session,
  type InsertSession,
  type Address,
  type InsertAddress,
  type OrderTracking,
  type InsertOrderTracking,
  type Subscription,
  type InsertSubscription,
  type SubscriptionHistory,
  type InsertSubscriptionHistory,
  type Review,
  type InsertReview,
  type CarbonSaving,
  type InsertCarbonSaving,
  type GreenReward,
  type InsertGreenReward,
  type RewardRedemption,
  type InsertRewardRedemption,
  type SaltFlavor,
  type InsertSaltFlavor
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id));
    return result[0];
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.slug, slug));
    return result[0];
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.category, category));
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.featured, true));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0];
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders);
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.id, id));
    return result[0];
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const result = await db.insert(orders).values(order).returning();
    return result[0];
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const result = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return result[0];
  }

  // Order Items
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const result = await db.insert(orderItems).values(orderItem).returning();
    return result[0];
  }

  // Contacts
  async getContacts(): Promise<Contact[]> {
    return await db.select().from(contacts);
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const result = await db.insert(contacts).values(contact).returning();
    return result[0];
  }

  // Wholesale Inquiries
  async getWholesaleInquiries(): Promise<WholesaleInquiry[]> {
    return await db.select().from(wholesaleInquiries);
  }

  async createWholesaleInquiry(inquiry: InsertWholesaleInquiry): Promise<WholesaleInquiry> {
    const result = await db.insert(wholesaleInquiries).values(inquiry).returning();
    return result[0];
  }

  // Newsletter Subscriptions
  async getNewsletterSubscriptions(): Promise<NewsletterSubscription[]> {
    return await db.select().from(newsletterSubscriptions);
  }

  async getNewsletterSubscriptionByEmail(email: string): Promise<NewsletterSubscription | undefined> {
    const result = await db
      .select()
      .from(newsletterSubscriptions)
      .where(eq(newsletterSubscriptions.email, email));
    return result[0];
  }

  async createNewsletterSubscription(subscription: InsertNewsletterSubscription): Promise<NewsletterSubscription> {
    const result = await db
      .insert(newsletterSubscriptions)
      .values(subscription)
      .returning();
    return result[0];
  }

  // User accounts
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUserById(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }
  
  async deleteUser(id: number): Promise<void> {
    // First delete related records in other tables to maintain referential integrity
    
    // Delete sessions
    await db.delete(sessions).where(eq(sessions.userId, id));
    
    // Delete addresses
    await db.delete(addresses).where(eq(addresses.userId, id));
    
    // Delete subscriptions
    await db.delete(subscriptions).where(eq(subscriptions.userId, id));
    
    // Finally delete the user
    await db.delete(users).where(eq(users.id, id));
  }

  // Authentication sessions
  async createSession(session: InsertSession): Promise<Session> {
    const result = await db.insert(sessions).values(session).returning();
    return result[0];
  }

  async getSessionByToken(token: string): Promise<Session | undefined> {
    const result = await db.select().from(sessions).where(eq(sessions.token, token));
    return result[0];
  }

  async deleteSession(token: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.token, token));
  }

  // User addresses
  async getAddressesByUserId(userId: number): Promise<Address[]> {
    return await db.select().from(addresses).where(eq(addresses.userId, userId));
  }

  async getAddressById(id: number): Promise<Address | undefined> {
    const result = await db.select().from(addresses).where(eq(addresses.id, id));
    return result[0];
  }

  async createAddress(address: InsertAddress): Promise<Address> {
    // If this is the default address, unset any other default addresses for this user
    if (address.isDefault) {
      await db
        .update(addresses)
        .set({ isDefault: false })
        .where(eq(addresses.userId, address.userId));
    }
    
    const result = await db.insert(addresses).values(address).returning();
    return result[0];
  }

  async updateAddress(id: number, addressData: Partial<InsertAddress>): Promise<Address | undefined> {
    // If setting this as default, unset any other default addresses for this user
    if (addressData.isDefault) {
      const address = await this.getAddressById(id);
      if (address) {
        await db
          .update(addresses)
          .set({ isDefault: false })
          .where(eq(addresses.userId, address.userId));
      }
    }
    
    const result = await db
      .update(addresses)
      .set({ ...addressData, updatedAt: new Date() })
      .where(eq(addresses.id, id))
      .returning();
    return result[0];
  }

  async deleteAddress(id: number): Promise<void> {
    await db.delete(addresses).where(eq(addresses.id, id));
  }

  // Order tracking
  async getOrderTrackingByOrderId(orderId: number): Promise<OrderTracking[]> {
    return await db
      .select()
      .from(orderTracking)
      .where(eq(orderTracking.orderId, orderId))
      .orderBy(desc(orderTracking.updatedAt));
  }

  async getOrderTrackingById(id: number): Promise<OrderTracking | undefined> {
    const result = await db.select().from(orderTracking).where(eq(orderTracking.id, id));
    return result[0];
  }

  async createOrderTracking(tracking: InsertOrderTracking): Promise<OrderTracking> {
    const result = await db.insert(orderTracking).values(tracking).returning();
    return result[0];
  }

  async updateOrderTracking(id: number, trackingData: Partial<InsertOrderTracking>): Promise<OrderTracking | undefined> {
    const result = await db
      .update(orderTracking)
      .set({ ...trackingData, updatedAt: new Date() })
      .where(eq(orderTracking.id, id))
      .returning();
    return result[0];
  }

  // Subscriptions
  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .orderBy(desc(subscriptions.createdAt));
  }

  async getSubscriptionById(id: number): Promise<Subscription | undefined> {
    const result = await db.select().from(subscriptions).where(eq(subscriptions.id, id));
    return result[0];
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const result = await db.insert(subscriptions).values(subscription).returning();
    return result[0];
  }

  async updateSubscription(id: number, subscriptionData: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const result = await db
      .update(subscriptions)
      .set({ ...subscriptionData, updatedAt: new Date() })
      .where(eq(subscriptions.id, id))
      .returning();
    return result[0];
  }

  async cancelSubscription(id: number): Promise<Subscription | undefined> {
    const result = await db
      .update(subscriptions)
      .set({ status: 'canceled', updatedAt: new Date() })
      .where(eq(subscriptions.id, id))
      .returning();
    return result[0];
  }

  // Subscription History
  async getSubscriptionHistoryBySubscriptionId(subscriptionId: number): Promise<SubscriptionHistory[]> {
    return await db
      .select()
      .from(subscriptionHistory)
      .where(eq(subscriptionHistory.subscriptionId, subscriptionId))
      .orderBy(desc(subscriptionHistory.deliveryDate));
  }

  async createSubscriptionHistory(history: InsertSubscriptionHistory): Promise<SubscriptionHistory> {
    const result = await db.insert(subscriptionHistory).values(history).returning();
    return result[0];
  }

  // Reviews
  async getReviews(): Promise<Review[]> {
    return await db.select().from(reviews);
  }
  
  async getReviewsByProductId(productId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.productId, productId))
      .orderBy(desc(reviews.createdAt));
  }
  
  async getReviewById(id: number): Promise<Review | undefined> {
    const result = await db.select().from(reviews).where(eq(reviews.id, id));
    return result[0];
  }
  
  async createReview(review: InsertReview): Promise<Review> {
    const result = await db.insert(reviews).values(review).returning();
    return result[0];
  }
  
  async updateReviewStatus(id: number, status: string): Promise<Review | undefined> {
    const result = await db
      .update(reviews)
      .set({ status })
      .where(eq(reviews.id, id))
      .returning();
    return result[0];
  }
  
  async deleteReview(id: number): Promise<void> {
    await db.delete(reviews).where(eq(reviews.id, id));
  }
  
  // Green Rewards - Carbon Savings
  async getCarbonSavingsByUserId(userId: number): Promise<CarbonSaving[]> {
    return await db
      .select()
      .from(carbonSavings)
      .where(eq(carbonSavings.userId, userId))
      .orderBy(desc(carbonSavings.createdAt));
  }
  
  async getAllCarbonSavings(): Promise<CarbonSaving[]> {
    return await db
      .select()
      .from(carbonSavings)
      .orderBy(desc(carbonSavings.createdAt));
  }
  
  async getCarbonSavingById(id: number): Promise<CarbonSaving | undefined> {
    const result = await db.select().from(carbonSavings).where(eq(carbonSavings.id, id));
    return result[0];
  }
  
  async createCarbonSaving(carbonSaving: InsertCarbonSaving): Promise<CarbonSaving> {
    const result = await db.insert(carbonSavings).values(carbonSaving).returning();
    const newCarbonSaving = result[0];
    
    // Update user's green rewards
    const existingReward = await this.getGreenRewardByUserId(carbonSaving.userId);
    if (existingReward) {
      await this.updateGreenReward(existingReward.id, {
        totalPoints: existingReward.totalPoints + carbonSaving.pointsEarned,
        lifetimeCarbonSaved: existingReward.lifetimeCarbonSaved + carbonSaving.carbonSaved,
      });
    } else {
      await this.createGreenReward({
        userId: carbonSaving.userId,
        totalPoints: carbonSaving.pointsEarned,
        lifetimeCarbonSaved: carbonSaving.carbonSaved,
        treesPlanted: 0,
      });
    }
    
    return newCarbonSaving;
  }
  
  async deleteCarbonSaving(id: number): Promise<void> {
    await db.delete(carbonSavings).where(eq(carbonSavings.id, id));
  }
  
  // Green Rewards - User Rewards
  async getGreenRewardByUserId(userId: number): Promise<GreenReward | undefined> {
    const result = await db.select().from(greenRewards).where(eq(greenRewards.userId, userId));
    return result[0];
  }
  
  async createGreenReward(greenReward: InsertGreenReward): Promise<GreenReward> {
    const result = await db.insert(greenRewards).values(greenReward).returning();
    return result[0];
  }
  
  async updateGreenReward(id: number, data: Partial<InsertGreenReward>): Promise<GreenReward | undefined> {
    const result = await db
      .update(greenRewards)
      .set({ ...data, lastUpdated: new Date() })
      .where(eq(greenRewards.id, id))
      .returning();
    return result[0];
  }
  
  // Green Rewards - Redemptions
  async getRewardRedemptionsByUserId(userId: number): Promise<RewardRedemption[]> {
    return await db
      .select()
      .from(rewardRedemptions)
      .where(eq(rewardRedemptions.userId, userId))
      .orderBy(desc(rewardRedemptions.createdAt));
  }
  
  async getRewardRedemptionById(id: number): Promise<RewardRedemption | undefined> {
    const result = await db.select().from(rewardRedemptions).where(eq(rewardRedemptions.id, id));
    return result[0];
  }
  
  async createRewardRedemption(redemption: InsertRewardRedemption): Promise<RewardRedemption> {
    const result = await db.insert(rewardRedemptions).values(redemption).returning();
    const newRedemption = result[0];
    
    // Update user's green rewards points balance
    const existingReward = await this.getGreenRewardByUserId(redemption.userId);
    if (existingReward) {
      let treesPlanted = existingReward.treesPlanted;
      if (redemption.rewardType === 'tree_planting' && redemption.treeCount) {
        treesPlanted += redemption.treeCount;
      }
      
      await this.updateGreenReward(existingReward.id, {
        totalPoints: existingReward.totalPoints - redemption.pointsSpent,
        treesPlanted: treesPlanted,
      });
    }
    
    return newRedemption;
  }
  
  async updateRewardRedemptionStatus(id: number, status: string): Promise<RewardRedemption | undefined> {
    const result = await db
      .update(rewardRedemptions)
      .set({ status })
      .where(eq(rewardRedemptions.id, id))
      .returning();
    return result[0];
  }
  
  // Salt Flavor Mood Matcher
  async getSaltFlavors(): Promise<SaltFlavor[]> {
    return await db.select().from(saltFlavors);
  }
  
  async getSaltFlavorById(id: number): Promise<SaltFlavor | undefined> {
    const result = await db.select().from(saltFlavors).where(eq(saltFlavors.id, id));
    return result[0];
  }
  
  async getSaltFlavorBySlug(slug: string): Promise<SaltFlavor | undefined> {
    const result = await db.select().from(saltFlavors).where(eq(saltFlavors.slug, slug));
    return result[0];
  }
  
  async getSaltFlavorsByMood(mood: string): Promise<SaltFlavor[]> {
    // This is a bit tricky since we need to check an array field
    // For PostgreSQL, we can use the "&&" operator to check array overlap
    // but Drizzle might not support this directly
    const allFlavors = await this.getSaltFlavors();
    return allFlavors.filter(flavor => flavor.matchingMoods.includes(mood as any));
  }
  
  async getSaltFlavorsByTasteProfile(tasteProfile: string): Promise<SaltFlavor[]> {
    return await db
      .select()
      .from(saltFlavors)
      .where(eq(saltFlavors.tasteProfile, tasteProfile as any));
  }
  
  async createSaltFlavor(saltFlavor: InsertSaltFlavor): Promise<SaltFlavor> {
    const result = await db.insert(saltFlavors).values(saltFlavor).returning();
    return result[0];
  }
  
  async updateSaltFlavor(id: number, data: Partial<InsertSaltFlavor>): Promise<SaltFlavor | undefined> {
    const result = await db
      .update(saltFlavors)
      .set(data)
      .where(eq(saltFlavors.id, id))
      .returning();
    return result[0];
  }
  
  async deleteSaltFlavor(id: number): Promise<void> {
    await db.delete(saltFlavors).where(eq(saltFlavors.id, id));
  }
}