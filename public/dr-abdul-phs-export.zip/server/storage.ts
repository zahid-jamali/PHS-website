import { 
  products, 
  orders, 
  orderItems, 
  contacts, 
  wholesaleInquiries, 
  newsletterSubscriptions,
  users,
  sessions,
  addresses,
  orderTracking,
  subscriptions,
  subscriptionHistory,
  reviews,
  carbonSavings,
  greenRewards,
  rewardRedemptions,
  saltFlavors,
  type Product, 
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type Contact,
  type InsertContact,
  type WholesaleInquiry,
  type InsertWholesaleInquiry,
  type NewsletterSubscription,
  type InsertNewsletterSubscription,
  type User,
  type InsertUser,
  type Session,
  type InsertSession,
  type Address,
  type InsertAddress,
  type OrderTracking,
  type InsertOrderTracking,
  type Subscription,
  type InsertSubscription,
  type SubscriptionHistory,
  type InsertSubscriptionHistory,
  type Review,
  type InsertReview,
  type CarbonSaving,
  type InsertCarbonSaving,
  type GreenReward,
  type InsertGreenReward,
  type RewardRedemption,
  type InsertRewardRedemption,
  type SaltFlavor,
  type InsertSaltFlavor
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import { DatabaseStorage } from './database-storage';

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Order Items
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Contacts
  getContacts(): Promise<Contact[]>;
  createContact(contact: InsertContact): Promise<Contact>;
  
  // Wholesale Inquiries
  getWholesaleInquiries(): Promise<WholesaleInquiry[]>;
  createWholesaleInquiry(inquiry: InsertWholesaleInquiry): Promise<WholesaleInquiry>;
  
  // Newsletter Subscriptions
  getNewsletterSubscriptions(): Promise<NewsletterSubscription[]>;
  getNewsletterSubscriptionByEmail(email: string): Promise<NewsletterSubscription | undefined>;
  createNewsletterSubscription(subscription: InsertNewsletterSubscription): Promise<NewsletterSubscription>;

  // User accounts
  getUsers(): Promise<User[]>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  
  // Authentication sessions
  createSession(session: InsertSession): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  deleteSession(token: string): Promise<void>;
  
  // User addresses
  getAddressesByUserId(userId: number): Promise<Address[]>;
  getAddressById(id: number): Promise<Address | undefined>;
  createAddress(address: InsertAddress): Promise<Address>;
  updateAddress(id: number, address: Partial<InsertAddress>): Promise<Address | undefined>;
  deleteAddress(id: number): Promise<void>;
  
  // Order tracking
  getOrderTrackingByOrderId(orderId: number): Promise<OrderTracking[]>;
  getOrderTrackingById(id: number): Promise<OrderTracking | undefined>;
  createOrderTracking(tracking: InsertOrderTracking): Promise<OrderTracking>;
  updateOrderTracking(id: number, tracking: Partial<InsertOrderTracking>): Promise<OrderTracking | undefined>;
  
  // Subscriptions
  getSubscriptionsByUserId(userId: number): Promise<Subscription[]>;
  getSubscriptionById(id: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, subscription: Partial<InsertSubscription>): Promise<Subscription | undefined>;
  cancelSubscription(id: number): Promise<Subscription | undefined>;
  
  // Subscription History
  getSubscriptionHistoryBySubscriptionId(subscriptionId: number): Promise<SubscriptionHistory[]>;
  createSubscriptionHistory(history: InsertSubscriptionHistory): Promise<SubscriptionHistory>;
  
  // Reviews
  getReviews(): Promise<Review[]>;
  getReviewsByProductId(productId: number): Promise<Review[]>;
  getReviewById(id: number): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  updateReviewStatus(id: number, status: string): Promise<Review | undefined>;
  deleteReview(id: number): Promise<void>;
  
  // Green Rewards - Carbon Savings
  getCarbonSavingsByUserId(userId: number): Promise<CarbonSaving[]>;
  getAllCarbonSavings(): Promise<CarbonSaving[]>;
  getCarbonSavingById(id: number): Promise<CarbonSaving | undefined>;
  createCarbonSaving(carbonSaving: InsertCarbonSaving): Promise<CarbonSaving>;
  deleteCarbonSaving(id: number): Promise<void>;
  
  // Green Rewards - User Rewards
  getGreenRewardByUserId(userId: number): Promise<GreenReward | undefined>;
  createGreenReward(greenReward: InsertGreenReward): Promise<GreenReward>;
  updateGreenReward(id: number, data: Partial<InsertGreenReward>): Promise<GreenReward | undefined>;
  
  // Green Rewards - Redemptions
  getRewardRedemptionsByUserId(userId: number): Promise<RewardRedemption[]>;
  getRewardRedemptionById(id: number): Promise<RewardRedemption | undefined>;
  createRewardRedemption(redemption: InsertRewardRedemption): Promise<RewardRedemption>;
  updateRewardRedemptionStatus(id: number, status: string): Promise<RewardRedemption | undefined>;
  
  // Salt Flavor Mood Matcher
  getSaltFlavors(): Promise<SaltFlavor[]>;
  getSaltFlavorById(id: number): Promise<SaltFlavor | undefined>;
  getSaltFlavorBySlug(slug: string): Promise<SaltFlavor | undefined>;
  getSaltFlavorsByMood(mood: string): Promise<SaltFlavor[]>;
  getSaltFlavorsByTasteProfile(tasteProfile: string): Promise<SaltFlavor[]>;
  createSaltFlavor(saltFlavor: InsertSaltFlavor): Promise<SaltFlavor>;
  updateSaltFlavor(id: number, data: Partial<InsertSaltFlavor>): Promise<SaltFlavor | undefined>;
  deleteSaltFlavor(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private productsData: Map<number, Product>;
  private ordersData: Map<number, Order>;
  private orderItemsData: Map<number, OrderItem>;
  private contactsData: Map<number, Contact>;
  private wholesaleInquiriesData: Map<number, WholesaleInquiry>;
  private newsletterSubscriptionsData: Map<number, NewsletterSubscription>;
  private usersData: Map<number, User>;
  private sessionsData: Map<string, Session>;
  private addressesData: Map<number, Address>;
  private orderTrackingData: Map<number, OrderTracking>;
  private subscriptionsData: Map<number, Subscription>;
  private subscriptionHistoryData: Map<number, SubscriptionHistory>;
  private reviewsData: Map<number, Review>;
  private carbonSavingsData: Map<number, CarbonSaving>;
  private greenRewardsData: Map<number, GreenReward>;
  private rewardRedemptionsData: Map<number, RewardRedemption>;
  private saltFlavorsData: Map<number, SaltFlavor>;
  
  private productIdCounter: number;
  private orderIdCounter: number;
  private orderItemIdCounter: number;
  private contactIdCounter: number;
  private wholesaleInquiryIdCounter: number;
  private newsletterSubscriptionIdCounter: number;
  private userIdCounter: number;
  private addressIdCounter: number;
  private orderTrackingIdCounter: number;
  private subscriptionIdCounter: number;
  private subscriptionHistoryIdCounter: number;
  private reviewIdCounter: number;
  private carbonSavingIdCounter: number;
  private greenRewardIdCounter: number;
  private rewardRedemptionIdCounter: number;
  private saltFlavorIdCounter: number;

  constructor() {
    this.productsData = new Map();
    this.ordersData = new Map();
    this.orderItemsData = new Map();
    this.contactsData = new Map();
    this.wholesaleInquiriesData = new Map();
    this.newsletterSubscriptionsData = new Map();
    this.usersData = new Map();
    this.sessionsData = new Map();
    this.addressesData = new Map();
    this.orderTrackingData = new Map();
    this.subscriptionsData = new Map();
    this.subscriptionHistoryData = new Map();
    this.reviewsData = new Map();
    this.carbonSavingsData = new Map();
    this.greenRewardsData = new Map();
    this.rewardRedemptionsData = new Map();
    this.saltFlavorsData = new Map();
    
    this.productIdCounter = 1;
    this.orderIdCounter = 1;
    this.orderItemIdCounter = 1;
    this.contactIdCounter = 1;
    this.wholesaleInquiryIdCounter = 1;
    this.newsletterSubscriptionIdCounter = 1;
    this.userIdCounter = 1;
    this.addressIdCounter = 1;
    this.orderTrackingIdCounter = 1;
    this.subscriptionIdCounter = 1;
    this.subscriptionHistoryIdCounter = 1;
    this.reviewIdCounter = 1;
    this.carbonSavingIdCounter = 1;
    this.greenRewardIdCounter = 1;
    this.rewardRedemptionIdCounter = 1;
    this.saltFlavorIdCounter = 1;
    
    // Initialize with sample data
    this.initializeProducts();
    this.initializeSaltFlavors();
  }
  
  private initializeSaltFlavors() {
    // Create sample salt flavors for testing
    const saltFlavors: InsertSaltFlavor[] = [
      {
        name: "Himalayan Pink Sea Salt",
        slug: "himalayan-pink-sea-salt",
        description: "Our classic pink Himalayan salt with a pure, mild taste that enhances any dish.",
        imageUrl: "/assets/salt-pink-classic.jpg",
        tasteProfile: "mild",
        matchingMoods: ["relaxed", "focused"],
        culinaryUses: ["seasoning", "cooking", "baking"],
        benefitsDescription: "Rich in minerals, enhances hydration, supports electrolyte balance.",
        productId: 1
      },
      {
        name: "Smoked Pink Salt",
        slug: "smoked-pink-salt",
        description: "Oak-smoked Himalayan salt that adds a deep, aromatic dimension to grilled dishes and hearty meals.",
        imageUrl: "/assets/salt-smoked.jpg",
        tasteProfile: "smoky",
        matchingMoods: ["creative", "adventurous"],
        culinaryUses: ["grilling", "meat rubs", "bbq"],
        benefitsDescription: "Adds depth of flavor without artificial additives, mineral-rich.",
        productId: 2
      },
      {
        name: "Pink Salt with Herbs",
        slug: "herbal-pink-salt",
        description: "A fragrant blend of Himalayan salt with Mediterranean herbs for a burst of flavor.",
        imageUrl: "/assets/salt-herbal.jpg",
        tasteProfile: "herbal",
        matchingMoods: ["energetic", "creative"],
        culinaryUses: ["finishing", "vegetable dishes", "salads"],
        benefitsDescription: "Combined benefits of salt and herbs, enhanced digestive support.",
        productId: 3
      },
      {
        name: "Spicy Pink Salt",
        slug: "spicy-pink-salt",
        description: "Himalayan salt infused with cayenne and chili for those who love heat in every bite.",
        imageUrl: "/assets/salt-spicy.jpg",
        tasteProfile: "spicy",
        matchingMoods: ["energetic", "adventurous"],
        culinaryUses: ["meat dishes", "spicy cuisine", "marinades"],
        benefitsDescription: "Metabolism support, circulation enhancement, flavor intensity.",
        productId: 4
      },
      {
        name: "Citrus Pink Salt",
        slug: "citrus-pink-salt",
        description: "Bright and zesty Himalayan salt infused with natural lemon and lime essence.",
        imageUrl: "/assets/salt-citrus.jpg",
        tasteProfile: "citrusy",
        matchingMoods: ["energetic", "relaxed"],
        culinaryUses: ["seafood", "poultry", "salad dressings"],
        benefitsDescription: "Vitamin C enhancement, digestive aid, natural flavor brightener.",
        productId: 5
      }
    ];
    
    // Add salt flavors to the map
    saltFlavors.forEach(flavor => {
      this.createSaltFlavor(flavor);
    });
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      // Existing Products
      {
        name: "Premium Salt Grinder",
        slug: "premium-salt-grinder",
        description: "Our premium salt grinder filled with authentic Pink Himalayan Salt crystals, perfect for everyday cooking. The adjustable ceramic grinding mechanism allows for custom coarseness settings.",
        price: 24.99,
        imageUrl: "/assets/CARVED SALT LAMPS 2.webp",
        category: "culinary",
        featured: true,
        inStock: true,
        weight: 8.5,
        dimensions: "3x3x8 inches"
      },
      {
        name: "Cooking Block Set",
        slug: "cooking-block-set",
        description: "Set of 2 Himalayan Salt cooking blocks for grilling, serving, and cooking with a naturally enhanced flavor. Perfect for searing seafood, meat, or serving cold appetizers.",
        price: 59.99,
        imageUrl: "/assets/salt-culinary-new.webp",
        category: "culinary",
        featured: true,
        inStock: true,
        weight: 16,
        dimensions: "8x8x2 inches"
      },
      {
        name: "Firebowl Salt Lamp",
        slug: "firebowl-salt-lamp",
        description: "Unique fire bowl design salt lamp hand-carved from authentic Himalayan salt crystals, creates a warm, relaxing ambiance that resembles a glowing flame.",
        price: 34.99,
        salePrice: 29.99,
        imageUrl: "/assets/FIREBOWL SALT.jpg",
        category: "home",
        featured: true,
        inStock: true,
        weight: 6,
        dimensions: "5x5x8 inches"
      },
      {
        name: "Bath Salt Blend",
        slug: "bath-salt-blend",
        description: "Therapeutic bath salt blend with essential oils for relaxation and detoxification. Our special formulation helps soothe sore muscles and improve skin health.",
        price: 19.99,
        imageUrl: "/assets/b-01.webp",
        category: "therapeutic",
        featured: true,
        inStock: true,
        weight: 16,
        dimensions: "4x4x6 inches"
      },
      {
        name: "Fine Ground Culinary Salt",
        slug: "fine-ground-culinary-salt",
        description: "Fine ground pink Himalayan salt, perfect for everyday cooking and baking. Contains over 84 trace minerals and elements for enhanced flavor and nutritional benefits.",
        price: 12.99,
        imageUrl: "/assets/SWAN CARVED SALT LAMP.png",
        category: "culinary",
        featured: false,
        inStock: true,
        weight: 16,
        dimensions: "3x3x6 inches"
      },
      {
        name: "Salt Inhaler",
        slug: "salt-inhaler",
        description: "Ceramic salt inhaler filled with pure Himalayan salt crystals for respiratory support. A natural way to potentially ease symptoms of allergies, asthma, and sinus conditions.",
        price: 29.99,
        imageUrl: "/assets/PHS CHUNK LAMP.webp",
        category: "therapeutic",
        featured: false,
        inStock: true,
        weight: 0.5,
        dimensions: "2x2x4 inches"
      },
      {
        name: "Himalayan Salt Tiles Set",
        slug: "himalayan-salt-tiles-set",
        description: "Set of 6 salt tiles perfect for building salt walls in saunas or halotherapy rooms. Creates a stunning visual feature while providing therapeutic benefits.",
        price: 149.99,
        imageUrl: "/assets/b-01.webp",
        category: "halotherapy",
        featured: false,
        inStock: true,
        weight: 30,
        dimensions: "8x4x2 inches each"
      },
      {
        name: "Halotherapy Salt",
        slug: "halotherapy-salt",
        description: "Pharmaceutical-grade salt specifically processed for halogenerators and salt therapy rooms. Micronized for optimal dispersion in salt therapy environments.",
        price: 39.99,
        imageUrl: "/assets/102.webp",
        category: "halotherapy",
        featured: false,
        inStock: true,
        weight: 22,
        dimensions: "10x8x4 inches"
      },
      {
        name: "Salt Therapy Room Design Service",
        slug: "salt-therapy-room-design",
        description: "Professional consultation and design service for creating custom salt therapy rooms for spas and wellness centers. Includes layout design, equipment selection, and installation guidance.",
        price: 1499.99,
        imageUrl: "/assets/KHEWRA SALT MINE IMAGES.jpg",
        category: "halotherapy",
        featured: true,
        inStock: true,
        weight: 0,
        dimensions: "Service"
      },
      
      // Salt Lamps Products

      {
        name: "PHS Chunk Lamp",
        slug: "phs-chunk-lamp",
        description: "Beautiful pink Himalayan chunks in an elegant iron pot, perfect for your living room or kitchen. Purifies surrounding air by removing pathogens and toxins with powerful detoxifying properties.",
        price: 39.99,
        imageUrl: "/assets/salt-lamps/chunk-lamp-2.webp",
        category: "home",
        featured: true,
        inStock: true,
        weight: 3.2,
        dimensions: "4x4x5 inches"
      },
      {
        name: "Carved Salt Lamp",
        slug: "carved-salt-lamp",
        description: "Artistically carved Himalayan salt lamps in various designs including spheres, pyramids, and bowls. Each piece is a beautiful functional art object.",
        price: 49.99,
        imageUrl: "/assets/salt-lamps/carved-salt-lamp.webp",
        category: "home",
        featured: true,
        inStock: true,
        weight: 6.0,
        dimensions: "6x6x7 inches"
      },
      {
        name: "USB Salt Lamp",
        slug: "usb-salt-lamp",
        description: "Compact USB-powered Himalayan salt lamps perfect for desks, offices, or travel. Enjoy the benefits of salt therapy wherever you go.",
        price: 24.99,
        imageUrl: "/assets/Salt-Lamp USB POWERED.jpg",
        category: "home",
        featured: true,
        inStock: true,
        weight: 1.5,
        dimensions: "3x3x4 inches"
      },
      {
        name: "Pyramid Salt Lamp",
        slug: "pyramid-salt-lamp",
        description: "Elegant pyramid-shaped Himalayan salt lamp with a smooth, polished surface. The unique geometric design makes this a stunning decorative piece for any room.",
        price: 42.99,
        imageUrl: "/assets/carved-salt-lamps.webp",
        category: "home",
        featured: true,
        inStock: true,
        weight: 5.5,
        dimensions: "5x5x7 inches"
      },
      {
        name: "Arabian Horse Salt Lamp",
        slug: "arabian-horse-salt-lamp",
        description: "Elegantly carved horse sculpture salt lamp, perfect as a decorative piece for any room.",
        price: 69.99,
        imageUrl: "/assets/PHS ARABIAN HORSE LAMP.webp",
        category: "home",
        featured: true,
        inStock: true,
        weight: 7,
        dimensions: "8x4x10 inches"
      },
      {
        name: "Swan Salt Lamp",
        slug: "swan-salt-lamp",
        description: "Elegant swan carved from pink Himalayan salt, a symbol of grace and natural beauty.",
        price: 59.99,
        imageUrl: "/assets/SWAN CARVED SALT LAMP.png",
        category: "home",
        featured: true,
        inStock: true,
        weight: 6,
        dimensions: "6x4x8 inches"
      },
      {
        name: "Organic Herb Salt Blend",
        slug: "organic-herb-salt-blend",
        description: "Premium Himalayan salt infused with organic herbs and spices. This versatile blend enhances the flavor of any dish with a complex, aromatic profile.",
        price: 14.99,
        imageUrl: "/assets/salt-lamps/105.webp",
        category: "culinary",
        featured: true,
        inStock: true,
        weight: 4.5,
        dimensions: "2x2x4 inches"
      },
      {
        name: "Salt Shot Glasses Set",
        slug: "salt-shot-glasses-set",
        description: "Set of 4 shot glasses hand-carved from Himalayan salt blocks. Perfect for cold tequila shots with a naturally salted rim and subtle mineral flavor.",
        price: 29.99,
        imageUrl: "/assets/salt-lamps/FIREBOWL SALT.jpg",
        category: "culinary",
        featured: false,
        inStock: true,
        weight: 2.8,
        dimensions: "2x2x2.5 inches each"
      },
      {
        name: "Foot Detox Salt Blocks",
        slug: "foot-detox-salt-blocks",
        description: "Pair of flat Himalayan salt blocks designed specifically for foot detoxification. Place feet on the blocks to potentially draw out toxins and reduce inflammation.",
        price: 49.99,
        imageUrl: "/assets/salt-lamps/CARVED SALT LAMPS 2.webp",
        category: "therapeutic",
        featured: true,
        inStock: true,
        weight: 12,
        dimensions: "10x6x2 inches each"
      },
      {
        name: "Coarse Cooking Salt",
        slug: "coarse-cooking-salt",
        description: "Coarse-ground Himalayan salt perfect for grinders and salt mills. The larger crystals are ideal for finishing dishes or use in brines and rubs.",
        price: 13.99,
        imageUrl: "/assets/salt-lamps/KHEWRA SALT MINE IMAGES.jpg",
        category: "culinary",
        featured: false,
        inStock: true,
        weight: 16,
        dimensions: "3x3x6 inches"
      },
      {
        name: "Salt Massage Stone Set",
        slug: "salt-massage-stone-set",
        description: "Set of 6 smooth, polished Himalayan salt stones for hot stone massage therapy. Can be heated or chilled for various therapeutic applications.",
        price: 38.99,
        imageUrl: "/assets/salt-lamps/KHEWRA SM 02.jpeg",
        category: "therapeutic",
        featured: false,
        inStock: true,
        weight: 6,
        dimensions: "3x2x1 inches each"
      },
      {
        name: "Professional Halotherapy Generator",
        slug: "professional-halotherapy-generator",
        description: "Commercial-grade halogenerator for professional salt therapy rooms. Precisely controls the dispersion of microscopic salt particles for optimal therapeutic effect.",
        price: 1299.99,
        imageUrl: "/assets/salt-lamps/CHUCK LAMPS.webp",
        category: "halotherapy",
        featured: true,
        inStock: true,
        weight: 35,
        dimensions: "18x12x10 inches"
      },
      {
        name: "Himalayan Cooking Salt Gift Set",
        slug: "himalayan-cooking-salt-gift-set",
        description: "Luxury gift set featuring three varieties of Himalayan cooking salt: fine ground, coarse ground, and infused with black truffle. Presented in elegant glass containers.",
        price: 49.99,
        imageUrl: "https://images.pexels.com/photos/5949897/pexels-photo-5949897.jpeg",
        category: "culinary",
        featured: true,
        inStock: true,
        weight: 20,
        dimensions: "12x4x8 inches"
      },
      {
        name: "Salt Wall DIY Installation Kit",
        slug: "salt-wall-diy-installation-kit",
        description: "Complete kit for building a 4x6 foot Himalayan salt wall, including salt bricks, mounting hardware, and LED lighting. Perfect for home salt rooms, spas, or yoga studios.",
        price: 599.99,
        imageUrl: "https://images.pexels.com/photos/5946068/pexels-photo-5946068.jpeg",
        category: "halotherapy",
        featured: true,
        inStock: true,
        weight: 150,
        dimensions: "48x12x24 inches"
      }
    ];

    sampleProducts.forEach(product => {
      this.createProduct(product);
    });
  }

  // Product Methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsData.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.productsData.values()).find(product => product.slug === slug);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.productsData.values()).filter(product => product.category === category);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values()).filter(product => product.featured);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const timestamp = new Date();
    
    // Ensure all required fields have proper values
    const newProduct: Product = {
      id,
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: product.price,
      salePrice: product.salePrice ?? null,
      imageUrl: product.imageUrl,
      category: product.category,
      featured: product.featured ?? null,
      inStock: product.inStock ?? null,
      weight: product.weight ?? null,
      dimensions: product.dimensions ?? null,
      createdAt: timestamp
    };
    
    this.productsData.set(id, newProduct);
    return newProduct;
  }

  // Order Methods
  async getOrders(): Promise<Order[]> {
    return Array.from(this.ordersData.values());
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.ordersData.get(id);
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const timestamp = new Date();
    
    // Ensure all required fields have proper values
    const newOrder: Order = {
      id,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone ?? null,
      address: order.address,
      city: order.city,
      state: order.state,
      zip: order.zip,
      country: order.country,
      total: order.total,
      status: order.status || "pending",
      createdAt: timestamp
    };
    
    this.ordersData.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.ordersData.get(id);
    if (!order) return undefined;
    
    const updatedOrder: Order = { ...order, status };
    this.ordersData.set(id, updatedOrder);
    return updatedOrder;
  }

  // Order Items Methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItemsData.values()).filter(item => item.orderId === orderId);
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemIdCounter++;
    const timestamp = new Date();
    const newOrderItem: OrderItem = { ...orderItem, id, createdAt: timestamp };
    this.orderItemsData.set(id, newOrderItem);
    return newOrderItem;
  }

  // Contact Methods
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contactsData.values());
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const id = this.contactIdCounter++;
    const timestamp = new Date();
    const newContact: Contact = { ...contact, id, createdAt: timestamp };
    this.contactsData.set(id, newContact);
    return newContact;
  }

  // Wholesale Inquiry Methods
  async getWholesaleInquiries(): Promise<WholesaleInquiry[]> {
    return Array.from(this.wholesaleInquiriesData.values());
  }

  async createWholesaleInquiry(inquiry: InsertWholesaleInquiry): Promise<WholesaleInquiry> {
    const id = this.wholesaleInquiryIdCounter++;
    const timestamp = new Date();
    
    // Ensure all required fields have proper values
    const newInquiry: WholesaleInquiry = {
      id,
      companyName: inquiry.companyName,
      contactName: inquiry.contactName,
      email: inquiry.email,
      phone: inquiry.phone,
      businessType: inquiry.businessType,
      interests: inquiry.interests,
      message: inquiry.message ?? null,
      createdAt: timestamp
    };
    
    this.wholesaleInquiriesData.set(id, newInquiry);
    return newInquiry;
  }

  // Newsletter Subscription Methods
  async getNewsletterSubscriptions(): Promise<NewsletterSubscription[]> {
    return Array.from(this.newsletterSubscriptionsData.values());
  }

  async getNewsletterSubscriptionByEmail(email: string): Promise<NewsletterSubscription | undefined> {
    return Array.from(this.newsletterSubscriptionsData.values()).find(
      subscription => subscription.email === email
    );
  }

  async createNewsletterSubscription(subscription: InsertNewsletterSubscription): Promise<NewsletterSubscription> {
    // Check if email already exists
    const existingSubscription = await this.getNewsletterSubscriptionByEmail(subscription.email);
    if (existingSubscription) return existingSubscription;
    
    const id = this.newsletterSubscriptionIdCounter++;
    const timestamp = new Date();
    const newSubscription: NewsletterSubscription = { ...subscription, id, createdAt: timestamp };
    this.newsletterSubscriptionsData.set(id, newSubscription);
    return newSubscription;
  }
  
  // User management methods
  async getUsers(): Promise<User[]> {
    return Array.from(this.usersData.values());
  }
  
  async getUserById(id: number): Promise<User | undefined> {
    return this.usersData.get(id);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(user => user.email === email);
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const timestamp = new Date();
    const newUser: User = {
      ...user,
      id,
      createdAt: timestamp,
      updatedAt: timestamp,
      isVerified: false,
      verificationToken: null,
      resetPasswordToken: null,
      resetPasswordExpires: null,
      phone: user.phone || null,
      profileImageUrl: user.profileImageUrl || null,
      role: user.role || 'user',
    };
    this.usersData.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUserById(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date()
    };
    this.usersData.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<void> {
    this.usersData.delete(id);
    
    // Also clean up related data
    // Delete sessions
    for (const [token, session] of this.sessionsData.entries()) {
      if (session.userId === id) {
        this.sessionsData.delete(token);
      }
    }
    
    // Delete addresses
    for (const [addressId, address] of this.addressesData.entries()) {
      if (address.userId === id) {
        this.addressesData.delete(addressId);
      }
    }
    
    // Delete or update subscriptions
    for (const [subscriptionId, subscription] of this.subscriptionsData.entries()) {
      if (subscription.userId === id) {
        this.subscriptionsData.delete(subscriptionId);
      }
    }
  }
  
  // Session management methods
  async createSession(session: InsertSession): Promise<Session> {
    const id = this.usersData.size + 1;
    const timestamp = new Date();
    const newSession: Session = {
      ...session,
      id,
      createdAt: timestamp
    };
    this.sessionsData.set(session.token, newSession);
    return newSession;
  }
  
  async getSessionByToken(token: string): Promise<Session | undefined> {
    return this.sessionsData.get(token);
  }
  
  async deleteSession(token: string): Promise<void> {
    this.sessionsData.delete(token);
  }
  
  // Address management methods
  async getAddressesByUserId(userId: number): Promise<Address[]> {
    return Array.from(this.addressesData.values())
      .filter(address => address.userId === userId);
  }
  
  async getAddressById(id: number): Promise<Address | undefined> {
    return this.addressesData.get(id);
  }
  
  async createAddress(address: InsertAddress): Promise<Address> {
    const id = this.addressIdCounter++;
    const timestamp = new Date();
    const newAddress: Address = {
      ...address,
      id,
      createdAt: timestamp,
      updatedAt: timestamp,
      addressLine2: address.addressLine2 || null,
      isDefault: address.isDefault || null
    };
    this.addressesData.set(id, newAddress);
    return newAddress;
  }
  
  async updateAddress(id: number, addressData: Partial<InsertAddress>): Promise<Address | undefined> {
    const address = await this.getAddressById(id);
    if (!address) return undefined;
    
    const updatedAddress: Address = {
      ...address,
      ...addressData,
      updatedAt: new Date()
    };
    this.addressesData.set(id, updatedAddress);
    return updatedAddress;
  }
  
  async deleteAddress(id: number): Promise<void> {
    this.addressesData.delete(id);
  }
  
  // Order tracking methods
  async getOrderTrackingByOrderId(orderId: number): Promise<OrderTracking[]> {
    return Array.from(this.orderTrackingData.values())
      .filter(tracking => tracking.orderId === orderId);
  }
  
  async getOrderTrackingById(id: number): Promise<OrderTracking | undefined> {
    return this.orderTrackingData.get(id);
  }
  
  async createOrderTracking(tracking: InsertOrderTracking): Promise<OrderTracking> {
    const id = this.orderTrackingIdCounter++;
    const timestamp = new Date();
    const newTracking: OrderTracking = {
      ...tracking,
      id,
      updatedAt: timestamp,
      trackingNumber: tracking.trackingNumber || null,
      carrier: tracking.carrier || null,
      estimatedDelivery: tracking.estimatedDelivery || null,
      actualDelivery: tracking.actualDelivery || null,
      locationUpdate: tracking.locationUpdate || null,
      notes: tracking.notes || null
    };
    this.orderTrackingData.set(id, newTracking);
    return newTracking;
  }
  
  async updateOrderTracking(id: number, trackingData: Partial<InsertOrderTracking>): Promise<OrderTracking | undefined> {
    const tracking = await this.getOrderTrackingById(id);
    if (!tracking) return undefined;
    
    const updatedTracking: OrderTracking = {
      ...tracking,
      ...trackingData,
      updatedAt: new Date()
    };
    this.orderTrackingData.set(id, updatedTracking);
    return updatedTracking;
  }
  
  // Subscription methods
  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptionsData.values())
      .filter(subscription => subscription.userId === userId);
  }
  
  async getSubscriptionById(id: number): Promise<Subscription | undefined> {
    return this.subscriptionsData.get(id);
  }
  
  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const id = this.subscriptionIdCounter++;
    const timestamp = new Date();
    const newSubscription: Subscription = {
      ...subscription,
      id,
      createdAt: timestamp,
      updatedAt: timestamp,
      status: subscription.status || 'active',
      quantity: subscription.quantity || 1,
      stripeSubscriptionId: subscription.stripeSubscriptionId || null
    };
    this.subscriptionsData.set(id, newSubscription);
    return newSubscription;
  }
  
  async updateSubscription(id: number, subscriptionData: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const subscription = await this.getSubscriptionById(id);
    if (!subscription) return undefined;
    
    const updatedSubscription: Subscription = {
      ...subscription,
      ...subscriptionData,
      updatedAt: new Date()
    };
    this.subscriptionsData.set(id, updatedSubscription);
    return updatedSubscription;
  }
  
  async cancelSubscription(id: number): Promise<Subscription | undefined> {
    const subscription = await this.getSubscriptionById(id);
    if (!subscription) return undefined;
    
    const canceledSubscription: Subscription = {
      ...subscription,
      status: 'cancelled',
      updatedAt: new Date()
    };
    this.subscriptionsData.set(id, canceledSubscription);
    return canceledSubscription;
  }
  
  async getSubscriptionHistoryBySubscriptionId(subscriptionId: number): Promise<SubscriptionHistory[]> {
    return Array.from(this.subscriptionHistoryData.values())
      .filter(history => history.subscriptionId === subscriptionId);
  }
  
  async createSubscriptionHistory(history: InsertSubscriptionHistory): Promise<SubscriptionHistory> {
    const id = this.subscriptionHistoryIdCounter++;
    const timestamp = new Date();
    const newHistory: SubscriptionHistory = {
      ...history,
      id,
      createdAt: timestamp
    };
    this.subscriptionHistoryData.set(id, newHistory);
    return newHistory;
  }
  
  // Reviews
  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviewsData.values());
  }
  
  async getReviewsByProductId(productId: number): Promise<Review[]> {
    return Array.from(this.reviewsData.values())
      .filter(review => review.productId === productId);
  }
  
  async getReviewById(id: number): Promise<Review | undefined> {
    return this.reviewsData.get(id);
  }
  
  async createReview(review: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const timestamp = new Date();
    
    // Create review with default values for required fields
    const newReview: Review = {
      id,
      productId: review.productId,
      userId: review.userId || null,
      rating: review.rating,
      title: review.title,
      content: review.content,
      isVerified: false,
      status: 'pending',
      createdAt: timestamp
    };
    
    this.reviewsData.set(id, newReview);
    return newReview;
  }
  
  async updateReviewStatus(id: number, status: string): Promise<Review | undefined> {
    const review = this.reviewsData.get(id);
    
    if (!review) {
      return undefined;
    }
    
    const updatedReview: Review = { ...review, status };
    this.reviewsData.set(id, updatedReview);
    
    return updatedReview;
  }
  
  async deleteReview(id: number): Promise<void> {
    this.reviewsData.delete(id);
  }
  
  // Green Rewards - Carbon Savings
  async getCarbonSavingsByUserId(userId: number): Promise<CarbonSaving[]> {
    const result: CarbonSaving[] = [];
    for (const saving of this.carbonSavingsData.values()) {
      if (saving.userId === userId) {
        result.push(saving);
      }
    }
    return result;
  }
  
  async getAllCarbonSavings(): Promise<CarbonSaving[]> {
    return Array.from(this.carbonSavingsData.values());
  }
  
  async getCarbonSavingById(id: number): Promise<CarbonSaving | undefined> {
    return this.carbonSavingsData.get(id);
  }
  
  async createCarbonSaving(carbonSaving: InsertCarbonSaving): Promise<CarbonSaving> {
    const id = this.carbonSavingIdCounter++;
    const newCarbonSaving: CarbonSaving = {
      id,
      ...carbonSaving,
      createdAt: new Date(),
    };
    
    this.carbonSavingsData.set(id, newCarbonSaving);
    
    // Update user's green rewards
    const existingReward = await this.getGreenRewardByUserId(carbonSaving.userId);
    if (existingReward) {
      await this.updateGreenReward(existingReward.id, {
        totalPoints: existingReward.totalPoints + carbonSaving.pointsEarned,
        lifetimeCarbonSaved: existingReward.lifetimeCarbonSaved + carbonSaving.carbonSaved,
      });
    } else {
      await this.createGreenReward({
        userId: carbonSaving.userId,
        totalPoints: carbonSaving.pointsEarned,
        lifetimeCarbonSaved: carbonSaving.carbonSaved,
        treesPlanted: 0,
      });
    }
    
    return newCarbonSaving;
  }
  
  async deleteCarbonSaving(id: number): Promise<void> {
    this.carbonSavingsData.delete(id);
  }
  
  // Green Rewards - User Rewards
  async getGreenRewardByUserId(userId: number): Promise<GreenReward | undefined> {
    for (const reward of this.greenRewardsData.values()) {
      if (reward.userId === userId) {
        return reward;
      }
    }
    return undefined;
  }
  
  async createGreenReward(greenReward: InsertGreenReward): Promise<GreenReward> {
    const id = this.greenRewardIdCounter++;
    const newGreenReward: GreenReward = {
      id,
      ...greenReward,
      lastUpdated: new Date(),
    };
    
    this.greenRewardsData.set(id, newGreenReward);
    return newGreenReward;
  }
  
  async updateGreenReward(id: number, data: Partial<InsertGreenReward>): Promise<GreenReward | undefined> {
    const existingReward = this.greenRewardsData.get(id);
    if (!existingReward) {
      return undefined;
    }
    
    const updatedReward: GreenReward = {
      ...existingReward,
      ...data,
      lastUpdated: new Date(),
    };
    
    this.greenRewardsData.set(id, updatedReward);
    return updatedReward;
  }
  
  // Green Rewards - Redemptions
  async getRewardRedemptionsByUserId(userId: number): Promise<RewardRedemption[]> {
    const result: RewardRedemption[] = [];
    for (const redemption of this.rewardRedemptionsData.values()) {
      if (redemption.userId === userId) {
        result.push(redemption);
      }
    }
    return result;
  }
  
  async getRewardRedemptionById(id: number): Promise<RewardRedemption | undefined> {
    return this.rewardRedemptionsData.get(id);
  }
  
  async createRewardRedemption(redemption: InsertRewardRedemption): Promise<RewardRedemption> {
    const id = this.rewardRedemptionIdCounter++;
    const newRedemption: RewardRedemption = {
      id,
      ...redemption,
      createdAt: new Date(),
    };
    
    this.rewardRedemptionsData.set(id, newRedemption);
    
    // Update user's green rewards points balance
    const existingReward = await this.getGreenRewardByUserId(redemption.userId);
    if (existingReward) {
      let treesPlanted = existingReward.treesPlanted;
      if (redemption.rewardType === 'tree_planting' && redemption.treeCount) {
        treesPlanted += redemption.treeCount;
      }
      
      await this.updateGreenReward(existingReward.id, {
        totalPoints: existingReward.totalPoints - redemption.pointsSpent,
        treesPlanted: treesPlanted,
      });
    }
    
    return newRedemption;
  }
  
  async updateRewardRedemptionStatus(id: number, status: string): Promise<RewardRedemption | undefined> {
    const existingRedemption = this.rewardRedemptionsData.get(id);
    if (!existingRedemption) {
      return undefined;
    }
    
    const updatedRedemption: RewardRedemption = {
      ...existingRedemption,
      status,
    };
    
    this.rewardRedemptionsData.set(id, updatedRedemption);
    return updatedRedemption;
  }
  
  // Salt Flavor Mood Matcher
  async getSaltFlavors(): Promise<SaltFlavor[]> {
    return Array.from(this.saltFlavorsData.values());
  }
  
  async getSaltFlavorById(id: number): Promise<SaltFlavor | undefined> {
    return this.saltFlavorsData.get(id);
  }
  
  async getSaltFlavorBySlug(slug: string): Promise<SaltFlavor | undefined> {
    for (const saltFlavor of this.saltFlavorsData.values()) {
      if (saltFlavor.slug === slug) {
        return saltFlavor;
      }
    }
    return undefined;
  }
  
  async getSaltFlavorsByMood(mood: string): Promise<SaltFlavor[]> {
    const result: SaltFlavor[] = [];
    for (const saltFlavor of this.saltFlavorsData.values()) {
      if (saltFlavor.matchingMoods.includes(mood as any)) {
        result.push(saltFlavor);
      }
    }
    return result;
  }
  
  async getSaltFlavorsByTasteProfile(tasteProfile: string): Promise<SaltFlavor[]> {
    const result: SaltFlavor[] = [];
    for (const saltFlavor of this.saltFlavorsData.values()) {
      if (saltFlavor.tasteProfile === tasteProfile) {
        result.push(saltFlavor);
      }
    }
    return result;
  }
  
  async createSaltFlavor(saltFlavor: InsertSaltFlavor): Promise<SaltFlavor> {
    const id = this.saltFlavorIdCounter++;
    const newSaltFlavor: SaltFlavor = {
      id,
      ...saltFlavor,
      createdAt: new Date(),
    };
    
    this.saltFlavorsData.set(id, newSaltFlavor);
    return newSaltFlavor;
  }
  
  async updateSaltFlavor(id: number, data: Partial<InsertSaltFlavor>): Promise<SaltFlavor | undefined> {
    const existingSaltFlavor = this.saltFlavorsData.get(id);
    if (!existingSaltFlavor) {
      return undefined;
    }
    
    const updatedSaltFlavor: SaltFlavor = {
      ...existingSaltFlavor,
      ...data,
    };
    
    this.saltFlavorsData.set(id, updatedSaltFlavor);
    return updatedSaltFlavor;
  }
  
  async deleteSaltFlavor(id: number): Promise<void> {
    this.saltFlavorsData.delete(id);
  }
}

// Use DatabaseStorage for production environment
export const storage = new DatabaseStorage();
